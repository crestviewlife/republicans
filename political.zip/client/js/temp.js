var serverUrl="http://localhost:4300/";
//serverUrl="http://ec2-13-58-254-234.us-east-2.compute.amazonaws.com:4300/";
var school_name = window.localStorage.getItem("school_name");
var lecture = window.localStorage.getItem("lecture");
var orderObj = [{itemId:5, quantity:7}, {itemId:6, quantity:8}, {itemId:8, quantity:3}];
var loggedInUser = window.localStorage.getItem("loggedInUser");
var password = window.localStorage.getItem("password");
var userDetails;
var temGender = 'MALE';
var tempAccess = 'ADMIN';
var processing=false;
var companyId;
var myApp = new Framework7({
    modalTitle: 'ALERT NOTIFICATION',
    material: true,
    pushState: true,
});
var $$ = Dom7;
var mainView = myApp.addView('.view-main', {
    dynamicNavbar: true,
    domCache: true
});
$(document).ready(deviceReady())
function deviceReady(){
    var socket = io("http://localhost:4300");
    //var socket = io("http://ec2-13-58-254-234.us-east-2.compute.amazonaws.com:4300");
    if (loggedInUser!=null) {
        //mainView.router.load({pageName: 'admin-main-page'});
        //$$(".school-name-div").text(school_name.toUpperCase())
        loginFn(loggedInUser,password,socket);
    }
    var minH = $(document).height()-50;
    $$(".sidebar").attr("style","background: #e9eaed;min-height:"+minH+"px;")
    $$(document).on("click",".access-panel-btn",  function(e) {
        var loggedUser = 'staff';
        myApp.modalLogin('','LOGIN BELOW', function (email_address, password) {
            loginFn(email_address,password,socket);
        });
    });
    function returnSocket(){
        return socket;
    }
    deviceReady.returnSocket=returnSocket;
    socket.on('getAllClaims', function(id,regId,url,status,name,date){
        if (status=='APPROVED') {
            var afterElem = "<a href='#' class='cool-btn' name='"+serverUrl+url+"'><i class='material-icons download-btn'>file_download</i></a> <a href='#'><i class='material-icons color-green'>done</i></a>";
        }else if(status=='PENDING'){
            var afterElem = "<a href='#' class='cool-btn' name='"+serverUrl+url+"'><i class='material-icons download-btn'>file_download</i></a> <a href='#' class='open-popover claim-popover' data-popover='.claim-option' id="+id+" regId='"+regId+"'><i class='material-icons color-gray'>more_vert</i></a>";
        }else{
            var afterElem = "<a href='#' class='cool-btn' name='"+serverUrl+url+"'><i class='material-icons download-btn'>file_download</i></a> <a href='#'><i class='material-icons color-red'>fiber_manual_record</i></a>";
        }
        if($$("[claim='all"+id+"']").length==0){
            $$(".display-all-claims-ul").append("<li id="+id+" regId='"+regId+"' claim='all"+id+"'><div class='item-content'><div class='item-media'><i class='material-icons color-cyan'>receipt</i></div><div class='item-inner'> <div class='item-title'>"+name+"</div><div class='item-after'>"+date+" "+afterElem+"</div></div></div></li>");
        }
    });
    socket.emit('getCompanyStatement', companyId,function(result){
       if (result.length>0) {
        $$(".show-expected-rev-div").text(result[0].expectedRevenue);
        $$(".show-gen-rev-div").text(result[0].receivedRevenue);
        $$(".show-arrear-rev-div").text(parseFloat(result[0].expectedRevenue) - parseFloat(result[0].receivedRevenue));
       } 
    });
    socket.on('getFinancialStatements', function(id,regId,amount,name,date){
        if($$("[payments='all"+id+"']").length==0){
            $$(".display-all-payments-ul").append("<li id="+id+" regId='"+regId+"' payments='all"+id+"'><div class='item-content'><div class='item-media'><i class='material-icons color-cyan'>receipt</i></div><div class='item-inner'> <div class='item-title'>"+name+"</div><div class='item-after'>"+date.slice(0,10)+" ZAR "+amount+"</div></div></div></li>");
        }
    });
    socket.on("newOrder", function(id,orderObj,total,tableNo,status,company){
        orderObj = JSON.parse(orderObj);
        if (company==companyId) {
            displayOrders(id,orderObj,total,status,tableNo,'new');
        }
    });
}
function loginFn(email_address,password,socket){
    socket.emit('loginStaff',email_address,password,function(result){
        if (result.length>0) {
          userDetails = result;
          $$(".username-btn").text(userDetails[0].staffName);
          loggedInUser = result[0].staffEmail;
          window.localStorage.setItem("loggedInUser",email_address);
          window.localStorage.setItem("password",password);
          $$(".companyNameH1").text(userDetails[1].storeName.toUpperCase());
          companyId = userDetails[0].companyId;
          mainView.router.load({pageName: 'mainPage'});
          getCategories(companyId);
          getOrders();
        }else{
          myApp.alert('Invalid login credentials.')
        }
    });
}
$$(document).on("click",".logout-btn",  function(e) {
    myApp.confirm('Are you sure you want to logout?','LOGOUT',function(){
        localStorage.removeItem('loggedInUser'); 
        mainView.router.load({pageName: 'welcome-page'}); 
    });
});
$$(document).on("click",".main-option-ul-li li,.mini-add-btn",  function(e) {
   mainView.router.load({pageName: $$(this).attr("id")});
});
$$(document).on("click",".btn-wrapper .col-50",  function(e) {
   mainView.router.load({pageName: $$(this).attr("id")});
});
$$(document).on("click",".ks-radio-access-btn",  function(e) {
   tempAccess = $$(this).val();
});
$$(document).on("click",".ks-radio-gender-btn",  function(e) {
   temGender = $$(this).val();
});
$$(document).on("click",".register-admin-btn",  function(e) {
    var socket = deviceReady.returnSocket(); 
    var adminName = $$(".admin-fname").val();
    var adminEmail = $$(".admin-email-input").val();
    var password = $$(".admin-password-input").val();
    var passwordAgain = $$(".admin-password-again").val();
    var storeName = $$(".store-name-input").val();
    var storePhone = $$(".store-phone-input").val();
    var storeAddress = $$(".store-address-input").val();
    var storeDes = $$(".store-des-input").val();
    var companyId = storeName.slice(0,3) +''+ Math.floor(Math.random()*899999+100000);
    if (adminName!="" && adminEmail!="" && password!="" && storeName!="" && storePhone!="" && storeDes!="") {
        if (password.length>5) {
            if (password==passwordAgain) {
                myApp.confirm('did you check your inputs correctly? Press ok to continue','CONFIRM',function(){
                    socket.emit('registerStore', adminName,adminEmail,password,storeName,storePhone,storeAddress,storeDes,companyId,function(cb){
                        if (cb) {
                            stopProcess();
                            myApp.alert(storeName+" has been added successfully!");
                            loginFn(adminEmail,password,socket)
                            $$(".staff-inputs input").val("");
                        }else{
                            myApp.alert(cb);
                        }
                    });
                    processStatus(10000,'Please wait while registering your store...');
                })
            }else{
                myApp.alert('password fields do not match');
            }
        }else{
            myApp.alert('password should be at least 6 characters long!');
        }
    }else{
        myApp.alert('Please all the input fields are required to be filled!');
    }
});
$$(document).on("click",".register-client-btn",  function(e) {
    var socket = deviceReady.returnSocket(); 
    var fname = $$(".client-fname-input").val();
    var lname = $$(".client-lname-input").val();
    var password = $$(".client-password-input").val();
    var passwordAgain = $$(".client-password-again").val();
    var email = $$(".client-email-input").val();
    var contact = $$(".client-phone-input").val();
    var address = $$(".client-address-input").val();
    var package = $$(".client-package-input").val();
    var username = $$(".client-username-input").val();
    var regId = company.slice(0,3) +''+ Math.floor(Math.random()*899999+100000);
    if (fname!="" && lname!="" && password!="" && email!="" && contact!="") {
        if (password.length>5) {
            if (password==passwordAgain) {
                myApp.confirm('did you check your inputs correctly? Press ok to continue','CONFIRM',function(){
                    socket.emit('registerClient', fname,lname,password,email,contact,temGender,address,package,regId,loggedInUser,company,username,function(cb){
                        if (cb==200) {
                            stopProcess();
                            myApp.alert(fname+" has been added successfully!");
                            $$(".staff-inputs input").val("");
                        }else{
                            myApp.alert(cb);
                        }
                    });
                    processStatus(10000,'Adding client, Please wait...');
                })
            }else{
                myApp.alert('password fields do not match');
            }
        }else{
            myApp.alert('password should be at least 6 characters long!');
        }
    }else{
        myApp.alert('Please all the input fields are required to be filled!');
    }
});
function getOrders(){
    var socket = deviceReady.returnSocket(); 
    socket.emit('getOrders', companyId,function(result){
        if (result.length>0) {
            for (var i = 0; i < result.length; i++){
                var id=result[i].id;
                var orderObj=result[i].orderObj;
                var total=result[i].total;
                var status=result[i].status;
                var tableNo=result[i].tableNo;
                displayOrders(id,orderObj,total,status,tableNo,'old');
            }
        }
    })
}
function displayOrders(id,orderObj,total,status,tableNo,oldStatus){
    if (oldStatus=='new') {
        $(".now-serving-speak").text("WE HAVE RECEIVED A NEW ORDER FROM TABLE "+tableNo).articulate('speak');
    }
    if (status=='PENDING') {
        var afterElem = "<i class='material-icons' style='color:yellow;'>lens</i>";
        if($$("[order='id"+id+"']").length==0){
            $$(".display-order-ul").append("<li order='id"+id+"' id='"+id+"' orderObj='"+orderObj+"' total='"+total+"' tableNo='"+tableNo+"' status='"+status+"'><div class='item-content'><div class='item-media' style='font-weight:bold; color:#757575;'>ORDER #"+id+"</div><div class='item-inner'> <div class='item-title' style='margin-top:5px;'>TABLE "+tableNo+"</div><div class='item-after' style='font-weight:bold;'>"+afterElem+"</div></div></div></li>");
        }
    }else{
        var afterElem = "<i class='material-icons' style='color:green;' id='"+id+"'>done_all</i>";
        if($$("[order='id"+id+"']").length==0){
            $$(".display-served-order-ul").append("<li order='id"+id+"' id='"+id+"' orderObj='"+orderObj+"' total='"+total+"' tableNo='"+tableNo+"' status='"+status+"'><div class='item-content'><div class='item-media' style='font-weight:bold; color:#757575;'>ORDER #"+id+"</div><div class='item-inner'> <div class='item-title' style='margin-top:5px;'>TABLE "+tableNo+"</div><div class='item-after' style='font-weight:bold;'>"+afterElem+"</div></div></div></li>");
        }
    }
}
$$(document).on("click",".action-btn",  function(e) {
    var id = $$(this).attr("id");
    var tableNo = $$(this).attr("tableNo");
    var status = $$(this).attr("status");
    var socket = deviceReady.returnSocket();
    if (status=="PENDING") {
        $(".now-serving-speak").text("ORDER "+id+" FOR TABLE "+tableNo+" IS NOW READY FOR COLLECTION. THANK YOU").articulate('speak');
        socket.emit("updateOrder",id,function(cb){
            if (cb) {
                $("[order='id"+id+"']").next().click();
                $("[order='id"+id+"']").remove();
                getOrders();
            }
        });
    }else{
        $(".now-serving-speak").text("THIS ORDER HAS BEEN SERVED ALREADY").articulate('speak');
    }
});
$$(document).on("click",".display-order-ul li,.display-served-order-ul li",  function(e) {
    var orderObj = JSON.parse($$(this).attr("orderObj"));
    var socket = deviceReady.returnSocket();
    var orderId = $$(this).attr("id");
    var tableNo = $$(this).attr("tableNo");
    var status = $$(this).attr("status");
    $$(".uk-slider-items,.action-btn,.total-div").html("");
    var header = 'ORDER #'+orderId+' TABLE '+$$(this).attr("tableNo"); 
    $$(".now-serving-header").text("ORDER DETAILS");
    $$(".now-serving-header").text(header);
    $$(".total-div").text("TOTAL AMOUNT R"+$$(this).attr("total"));
    $$(".waiting-order-div").hide();
    $$(".order-card").show();
    $$(".display-order-ul li, .display-served-order-ul li").removeClass("active-li");
    $$(this).addClass("active-li");
    if (status=='DONE') {
        var elem = "<i class='material-icons' style='color:indigo'>lens</i>";
    }else{
        var elem = "<i class='material-icons' style='color:green'>done_all</i>";
        setTimeout(function(){
            $(".now-serving-speak").text("NOW SERVING ORDER "+orderId+" ON TABLE "+tableNo).articulate('speak');
        },3000);
    }
    $$(".action-btn").attr("id",orderId).attr("tableNo",tableNo).attr("status",status);
    slidePhotos()
    $$(".action-btn").html(elem);
    for (var i = 0; i < orderObj.length; i++){
        (function(x){
          setTimeout(function () {
            var itemId = orderObj[x].itemId;
            var quantity = orderObj[x].quantity;
            socket.emit('getItemDetails', itemId,function(result){
                var itemName = result[0].itemName;
                var itemIcon = serverUrl + result[0].url;
                $$(".uk-slider-items").append("<li class='uk-width-3-4'><div class='card'><div class='card-content'><div class='uk-panel' style='height: 300px;'><img src='"+itemIcon+"'></div></div><div class='card-footer' style='background: #e9eaed;'><a href='#' class='link'>"+itemName+"</a><a href='#' class='link' style='font-weight:bolder;'>"+ parseFloat(quantity) +' * R'+ parseFloat(result[0].itemPrice) +" = R"+ parseFloat(quantity) * parseFloat(result[0].itemPrice) +"</a></div></li>");
            });
          }, 500 * i);
        })(i);
    }
});
function slidePhotos(){
    var recInterval = setInterval(function() {
        $$(".slide-photos-btn").click();
    },4000)
}
function processStatus(time,text){
    myApp.showPreloader(text);
    processing=true;
    setTimeout(function(){
         if(processing==true){
            myApp.hidePreloader();
            myApp.alert('There was an error, Or check your internet connection');
            processing=false;
         }
    },time);
}
function stopProcess(){
    processing=false;
    myApp.hidePreloader();
}
$$(document).on("click","#view-clients-page",  function(e) {
   var socket = deviceReady.returnSocket(); 
   socket.emit('getClients', company,function(result){
    if (result.length>0) {
        for (var i = 0; i < result.length; i++){
            var user=result[i].user;
            var name=result[i].name;
            var surname=result[i].surname;
            var address=result[i].address;
            var package=result[i].policy;
            var sex=result[i].sex;
            var regId=result[i].reg;
            if($$("[clients='id"+regId+"']").length==0){
                $$(".display-clients-ul").append("<li clients='id"+regId+"' name='"+name+"' surname='"+surname+"' address='"+address+"' package='"+package+"' sex='"+sex+"' regId='"+regId+"'><div class='item-content'><div class='item-media'><i class='material-icons color-cyan'>account_circle</i></div><div class='item-inner'> <div class='item-title'>"+name+" "+surname+"</div><div class='item-after'>"+package.toUpperCase()+"</div></div></div></li>");
            }
        }
    }else{
        //myApp.alert(company+" does not have any clients yet");
    }
   });
});
$$(document).on("click",".display-clients-ul li",  function(e) {
   mainView.router.load({pageName: 'client-profile-page'});
   var fname = $$(this).attr("name");
   var lname = $$(this).attr("surname");
   var regId = $$(this).attr("regId");
   var package = $$(this).attr("package");
   $$(".add-dependant-btn").attr("package",package).attr("regId",regId);
   $$(".show-fname-on-profile").text(fname+' '+lname+'`s PROFILE');
   getDependants(regId);
   getClaims(regId);
});
$$(document).on("click",".toggle-form-category",  function(e) {
   $(".hidden-form-category").slideToggle();
});
$$(document).on("click",".add-category-btn",  function(e) {
    var socket = deviceReady.returnSocket();
    var category = $$(".category-name-input").val();
    myApp.confirm('Are you sure you want to add '+category+' as a category?','CONFIRM',function(){
        socket.emit('addCategory',category,companyId,function(cb){
            if (cb) {
                myApp.alert(category+" has been added successfully");
                getCategories(companyId);
                $(".hidden-form-category").slideToggle();
                $$(".staff-inputs input").val("");
            }else{
                myApp.alert("Sorry we could not add this category!");
            }
            stopProcess();
        });
        processStatus(10000,"Adding category, Please wait...");              
    })
});
function getCategories(companyId){
    var socket = deviceReady.returnSocket();
    socket.emit("getCategories", companyId,function(result){
        if (result.length>0) {
            for (var i = 0; i < result.length; i++){
                var id=result[i].id;
                var category=result[i].category;
                if($$("[category='id"+id+"']").length==0){
                    $$(".display-categories-ul").append("<li id="+id+" category='id"+id+"' name='"+category+"'><div class='item-content'><div class='item-media'><i class='material-icons color-indigo'>add_shopping_cart</i></div><div class='item-inner'> <div class='item-title'>"+category+"</div><div class='item-after'></div></div></div></li>");
                }
            }
        }
    })
}
$$(document).on("click",".display-categories-ul li",  function(e) {
    var id = $$(this).attr("id");
    var name = $$(this).attr("name");
    $$(".show-item-header").text("ALL ITEMS UNDER "+name.toUpperCase());
    $$(".save-item-btn").attr("id",id);
    mainView.router.load({pageName: 'categories'});
    getItems(id);
});
function getItems(id){
    var socket = deviceReady.returnSocket();
    socket.emit('getItems',id,function(result){
       if (result.length>0) {
            for (var i = 0; i < result.length; i++){
                var id=result[i].id;
                var url=result[i].url;
                var itemName=result[i].itemName;
                var itemPrice=result[i].itemPrice;
                var itemQuantity=result[i].itemQuantity;
                var itemDes=result[i].itemDes;
                var fileUrl = serverUrl+url;
                if($(".rm-third-col").length!=0){
                    $$(".rm-third-col").html("<div class='card-header' style='color:#757575;font-weight:bold;'>"+itemName.toUpperCase()+"</div><div class='card-content card-content-img'><center><img src='"+fileUrl+"' class='itemIcon'></center></div><div class='card-footer' style='background: #e9eaed;'><a href='#' class='link'>R "+itemPrice+"</a><a href='#' class='link'>"+itemQuantity+"</a><a href='#' class='link'><i class='material-icons' style='margin-top: 7px;'>edit</i></a></div>");
                    $$(".third-col").removeClass("rm-third-col");
                    console.log(itemName);
                }else if($(".rm-second-col").length!=0){
                    $$(".rm-second-col").html("<div class='card-header' style='color:#757575;font-weight:bold;'>"+itemName.toUpperCase()+"</div><div class='card-content card-content-img'><center><img src='"+fileUrl+"' class='itemIcon'></center></div><div class='card-footer' style='background: #e9eaed;'><a href='#' class='link'>R "+itemPrice+"</a><a href='#' class='link'>"+itemQuantity+"</a><a href='#' class='link'><i class='material-icons' style='margin-top: 7px;'>edit</i></a></div>");
                    $$(".second-col").removeClass("rm-second-col");
                    console.log(itemName);
                }else{
                    $$(".display-items-ul").prepend("<div class='row'> <div class='card col-30'> <div class='card-header' style='color:#757575;font-weight:bold;'>"+itemName.toUpperCase()+"</div><div class='card-content card-content-img'><center><img src='"+fileUrl+"' class='itemIcon'></center></div><div class='card-footer' style='background: #e9eaed;'><a href='#' class='link'>R "+itemPrice+"</a><a href='#' class='link'>"+itemQuantity+"</a><a href='#' class='link'><i class='material-icons' style='margin-top: 7px;'>edit</i></a></div></div>  <div class='col-30 second-col rm-second-col card'></div>    <div class='col-30 third-col rm-third-col card'></div></div>");
                    console.log(itemName);
                }
            }
       } 
    });
}
$$(document).on("click",".browse-file-btn",  function(e) {
    $$(".hiddenFileInput").click();
});
$$(document).on("change",".hiddenFileInput",  function(e) {
    var fileReader = new FileReader();
    fileReader.onload = function () {
        var data = fileReader.result;
        if(base64Mime(data)=='image/jpg' || base64Mime(data)=='image/png' || base64Mime(data)=='image/jpeg') {
            $$(".preview-item-image").html("<center><img src='"+data+"' style='max-width: 99%'></center>");
        }
    };
    fileReader.readAsDataURL($(this).prop('files')[0]);
});
$$(document).on("click",".save-item-btn",  function(e) {
    var itemName = $$(".item-name-input").val();
    var itemPrice = $$(".item-price-input").val();
    var itemQuantity = $$(".item-quantity-input").val();
    var itemDes = $$(".item-des-input").val();
    var categoryId = $$(this).attr("id");
    if (itemName!="" && itemPrice!="") {
        myApp.confirm('Have you entered your inputs correctly?','CONFIRM INPUTS',function(){
            var form_data = new FormData();
            var fileUrl = $('.hiddenFileInput').prop("files")[0];
            var fileUri = $$('.hiddenFileInput').val();
            var filename =  Date.now() + '.'+fileUri.slice(-3);
            form_data.append("categoryId", categoryId);
            form_data.append("fileUrl", fileUrl);
            form_data.append("filename", filename);
            form_data.append("companyId", companyId);

            form_data.append("itemName", itemName);
            form_data.append("itemPrice", itemPrice);
            form_data.append("itemQuantity", itemQuantity);
            form_data.append("itemDes", itemDes);

            processStatus(60000,'Saving item, please wait...');
            $.ajax({
                url : serverUrl+'uploadFile',
                type : 'POST',
                data : form_data,
                processData: false,
                contentType: false,
                success : function(cb) {
                    if (cb) {
                        myApp.alert('Your item has been added successfully');
                        $$(".display-items-ul").html("");
                        getItems(categoryId);
                    }else{
                        myApp.alert('There was an error while trying to upload your item');
                    }
                    stopProcess();
                }
            });
        })
    }else{
        myApp.alert("Please fill in all fields to proceed!");
    }
});
$$(document).on("click",".place-order-btn",  function(e) {
    var form_data = new FormData();    
    form_data.append("itemName", 'testing');
    var total = 300;
    var tableNo = 4;
    var placedBy = loggedInUser
    orderObj = JSON.stringify(orderObj)
    $.ajax({
        url : serverUrl+'order/'+orderObj+'/total/'+total+'/companyId/'+companyId+'/tableNo/'+tableNo+'/placedBy/'+placedBy,
        type : 'GET',
        data : form_data,
        processData: false,
        contentType: false,
        success : function(cb) {}
    });
});
function getClaims(regId){
    var socket = deviceReady.returnSocket(); 
    socket.emit('getClientClaims', regId,function(result){
        if (result.length>0) {
            for (var i = 0; i < result.length; i++){
                var id=result[i].id;
                var url=result[i].url;
                var date=result[i].date;
                var status=result[i].status;
                if (status=='APPROVED') {
                    var afterElem = "<a href='#' class='cool-btn' name='"+serverUrl+url+"'><i class='material-icons download-btn'>file_download</i></a> <a href='#'><i class='material-icons color-green'>done</i></a>";
                }else if(status=='PENDING'){
                    var afterElem = "<a href='#' class='cool-btn' name='"+serverUrl+url+"'><i class='material-icons download-btn'>file_download</i></a> <a href='#' class='open-popover claim-popover' data-popover='.claim-option' id="+id+" regId='"+regId+"'><i class='material-icons color-gray'>more_vert</i></a>";
                }else{
                    var afterElem = "<a href='#' class='cool-btn' name='"+serverUrl+url+"'><i class='material-icons download-btn'>file_download</i></a> <a href='#'><i class='material-icons color-red'>fiber_manual_record</i></a>";
                }
                if($$("[claim='id"+id+"']").length==0){
                    $$(".display-claims-ul").append("<li id="+id+" regId='"+regId+"' claim='id"+id+"'><div class='item-content'><div class='item-media'><i class='material-icons color-cyan'>receipt</i></div><div class='item-inner'> <div class='item-title'>"+date+"</div><div class='item-after'>"+afterElem+"</div></div></div></li>");
                }
            }
        }else{
            myApp.alert(company+" does not have any clients yet");
        }
    })
}
var elem;
$$(document).on("click",".claim-popover",  function(e) {
   var id = $$(this).attr("id");
   var regId = $$(this).attr("regId");
   elem = $$(this);
   $$(".approve-claim-btn,.decline-claim-btn").attr("id",id).attr("regId",regId);
});
$$(document).on("click",".cool-btn",  function(e) {
   window.location = $$(this).attr("name");
});
$$(document).on("click",".approve-claim-btn",  function(e) {
    var id = $$(this).attr("id");
    var regId = $$(this).attr("regId");
    var socket = deviceReady.returnSocket();
    myApp.confirm('Click ok button to approve this claim','CONFIRM APPROVAL',function(){
        socket.emit("approveClaim",id,function(cb){
            stopProcess();
            if (cb) {
                myApp.alert('You have successfully approved this claim!');
                elem.html("<i class='material-icons color-green'>done</i>").removeClass('open-popover');
            }else{
                myApp.alert('Error while trying to approve this claim!')
            }
        });
        processStatus(10000,'Please wait while processing the claim...');
    })
});
$$(document).on("click",".decline-claim-btn",  function(e) {
    var id = $$(this).attr("id");
    var regId = $$(this).attr("regId");
    var socket = deviceReady.returnSocket();
    myApp.confirm('Click ok button to decline this claim','DECLINE CLAIM',function(){
        socket.emit("declineClaim",id,function(cb){
            stopProcess();
            if (cb) {
                myApp.alert('You have successfully declined this claim!');
                elem.html("<i class='material-icons color-red'>fiber_manual_record</i>").removeClass('open-popover');
            }else{
                myApp.alert('Error while trying to decline this claim!')
            }
        });
        processStatus(10000,'Please wait while declining the claim...');
    })
});
$$(document).on("change",".checkbox-ben-btn",  function(e) {
    if ($$(this).attr("checked")==null) {
        $$(this).attr("checked",true);
        $$(".shares-slider-li").show();
    }else{
        $$(this).removeAttr('checked');
        $$(".shares-slider-li").hide();
    }
});
$$(document).on("change",".range-slider-share",  function(e) {
    $$(".show-shares-span").text($$(this).val()+'%');
});
$$(document).on("click",".display-dependants-ul li",  function(e) {
    var id = $$(this).attr("id");
    var name = $$(this).attr("name");
    var socket = deviceReady.returnSocket();
    myApp.confirm('Remove '+name+' as a dependant?','REMOVE DEPENDANT',function(){
        socket.emit("removeDependant",id,function(cb){
            stopProcess();
            if (cb) {
                myApp.alert('You have successfully removed '+name+' as a dependant!');
                $$("[dependant='id"+id+"']").remove();
                getDependants(regId);
            }else{
                myApp.alert('Error while trying to remove '+name);
            }
        });
        processStatus(10000,'Please wait while removing '+name+'...');
    });
});
$$(document).on("click","#view-claims-page",  function(e) {
    var socket = deviceReady.returnSocket();
    socket.emit('getAllClaims', company,function(result){})  
});
$$(document).on("click","#financial-page",  function(e) {
    var socket = deviceReady.returnSocket();
    socket.emit('getFinancialStatements', company,function(result){})  
});
$$(document).on("click","#view-company-page",  function(e) {
    getCompanies();
});
function getCompanies(){
    var socket = deviceReady.returnSocket();
    socket.emit('getCompanies', company,function(result){
        if (result.length>0) {
            for (var i = 0; i < result.length; i++){
                var id=result[i].id;
                var name=result[i].name;
                var phone=result[i].phone;
                var status=result[i].status;
                var address=result[i].address;
                var website=result[i].website;
                if (status=='activate') {
                    var afterElem = "<a href='#'><i class='material-icons color-green'>brightness_1</i></a>";
                }else if(status=='suspend'){
                    var afterElem = "<a href='#'><i class='material-icons color-red'>brightness_1</i></a>";
                }
                if($$("[company='id"+id+"']").length==0){
                    $$(".display-all-company-ul").append("<li id="+id+" company='id"+id+"' website='"+website+"' phone='"+phone+"' class='open-popover company-popover-btn' data-popover='.company-popover'><div class='item-content'><div class='item-media'><i class='material-icons color-cyan'>receipt</i></div><div class='item-inner'> <div class='item-title'>"+name+"</div><div class='item-after' statusAct='"+id+"'>"+afterElem+"</div></div></div></li>");
                }
            }
        }
    })   
}
$$(document).on("click",".company-popover-btn",  function(e) {
    var id = $$(this).attr("id");
    var phone = $$(this).attr("phone");
    var website = $$(this).attr("website");
    $$(".com-web-btn,.com-phone-btn,.com-act-btn,.com-sus-btn").attr("id",id).attr("phone",phone).attr("website",website);
    $$(".com-phone-btn").text(phone);
});
$$(document).on("click",".com-web-btn",  function(e) {
    window.location = $$(this).attr("website");
});
$$(document).on("click",".toggle-company-form-btn",  function(e) {
    $(".toggle-company-form").slideToggle();
});
$$(document).on("click",".com-act-btn,.com-sus-btn",  function(e) {
    var socket = deviceReady.returnSocket();
    var status = $$(this).attr('title');
    var id = $$(this).attr("id");
    myApp.confirm('Are you sure you want to '+status+'?','CONFIRM OPERATION',function(){
        socket.emit('activationStatus', id,status,function(cb){
            if (cb) {
                myApp.alert("Company status has been changed!");
                if (status=='activate') {
                    $$("[statusAct='"+id+"']").html("<a href='#'><i class='material-icons color-green'>brightness_1</i></a>");
                }else{
                    $$("[statusAct='"+id+"']").html("<a href='#'><i class='material-icons color-red'>brightness_1</i></a>");
                }
            }
            stopProcess();
        })  
        processStatus(10000,'Please wait while changing company status...');
    })
});
$$(document).on("click",".register-company-btn",  function(e) {
    var socket = deviceReady.returnSocket();
    var companyName = $$(".company-name").val();
    var companyAddress = $$(".company-address").val();
    var adminName = $$(".admin-name").val();
    var password = $$(".admin-password-input").val();
    var companyWebsite = $$(".company-website").val();
    var adminEmail = $$(".admin-email-input").val();
    var adminphone = $$(".admin-phon-input").val();
    var adminSurname = $$(".admin-surname").val();
    var passwordAgain = $$(".admin-password-again").val();
    var regTime = Date.now();
    if (companyName!="" && companyAddress!="" && adminName!="" && password!="" && adminEmail!="" && adminphone!="" && adminSurname!="") {
        if (password.length>5) {
            if (password==passwordAgain) {
                myApp.confirm('Press ok to register this company','CONFIRM',function(){
                    socket.emit('registerCompany',companyName,companyAddress,adminName,adminphone,password,companyWebsite,adminEmail,adminSurname,regTime,temGender,loggedInUser,function(cb){
                        if (cb==200) {
                            myApp.alert(companyName+" has been added successfully!");
                            getCompanies();
                        }else{
                            myApp.alert(cb);
                        }
                        stopProcess();
                    });
                    processStatus(10000, 'Please wait while registering '+companyName+'...');
                })
            }else{
                myApp.alert('password fields do not match!');
            }
        }else{
            myApp.alert('Password length should be at least 6 characters!')
        }
    }else{
        myApp.alert("Please fill in all fields!");
    }
});
function base64Mime(encoded) {
  var result = null;
  if (typeof encoded !== 'string') {
    return result;
  }
  var mime = encoded.match(/data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+).*,.*/);
  if (mime && mime.length) {
    result = mime[1];
  }
  return result;
}