var serverUrl="http://localhost:3500/";
var processing=false;
var userArray;
var sessionedEmail = window.localStorage.getItem("email");
var sessionedPass = window.localStorage.getItem("password");
var myApp = new Framework7({
    modalTitle: 'ALERT NOTIFICATION',
    material: true,
    pushState: true,
});
var $$ = Dom7;
var mainView = myApp.addView('.view-main', {
    dynamicNavbar: true,
    domCache: true
});
$(document).ready(deviceReady())
function deviceReady(){
    var socket = io("http://localhost:3500");
    function returnSocket(){
        return socket;
    }
    deviceReady.returnSocket=returnSocket;
    if (sessionedEmail!=null) {
        loginFn(sessionedEmail,sessionedPass);
    }
    var str = "+27817752642"
    //alert(str.slice(0,3))
}
function processStatus(time,text){
    myApp.showPreloader(text);
    processing=true;
    setTimeout(function(){
         if(processing==true){
            myApp.hidePreloader();
            myApp.alert('There was an error, Or check your internet connection');
            processing=false;
         }
    },time);
}
function stopProcess(){
    processing=false;
    myApp.hidePreloader();
}
function showToast(message) {
  myApp.alert(message);
}
$$(document).on("click",".create-account-btn", function(e){
    var province = $$(".select-province-input").val();
    var gender = $$(".select-gender-input").val();
    var occupation = $$(".select-occupation-input").val();
    var fname = $$(".fname-input").val();
    var nationalId = $$(".nationalId-input").val();
    var email = $$(".email-input").val();
    var city = $$(".city-input").val();
    var password = "000000";
    var position = "PUBLIC MEMBER";
    var socket = deviceReady.returnSocket();
    if (fname.length>2) {
        if (email!="") {
            if (city!="") {
                if (nationalId.length>7) {
                    myApp.confirm('Have you provided correct details?','CONFIRM',function(buttonIndex){
                        socket.emit("create-account",province,gender,occupation,fname,nationalId,email,city,password,position,function(cb){
                            stopProcess();
                            if (cb==true) {
                                $$(".inputs-list input").val("");
                                showToast("Registration was successful!");
                            }else{
                                showToast(cb);
                            }                    
                        }); 
                    }); 
                }else{
                    showToast("Invalid National Identification!");
                }
                processStatus(10000,'Creating your account, Please wait...');
            }else{
                showToast("Your City is required!");
            }
        }else{
            showToast("Your email address is required!");
        }
    }else{
        showToast("Invalid name, Please enter a valid name");
    }
});
$$(document).on("click",".login-btn", function(e){
    var email = $$(".email-input-login").val();
    var password = $$(".password-input-login").val();
    if (email!="" && password!="") {
        loginFn(email,password);
    }else{
        showToast("Fill all the fields to proceed!");
    }
});
$$(document).on("click",".log-out-btn", function(e){
    myApp.confirm('Are you sure you want to log out?','CONFIRM LOG OUT',function(buttonIndex){
        mainView.router.load({pageName: 'welcome-page'});
        window.localStorage.removeItem("email");
        window.localStorage.removeItem("password");
    });
});
function loginFn(email,password){
    var socket = deviceReady.returnSocket();
    socket.emit("login",email,password,function(result){
        stopProcess();
        if (result.length>0) {
            userArray = result;
            window.localStorage.setItem("email",userArray[0].email);
            window.localStorage.setItem("password",userArray[0].password);
            $$(".header-show-fname").text(userArray[0].fname.split(' ')[0]);
            mainView.router.load({pageName: 'main-page'});
        }else{
            showToast("Invalid email address or password!");
        }
    });
    processStatus(10000,'Trying to log you in, Please wait...');
}
myApp.onPageInit('main-page', function (page) {
    //checkLoginStatus();
});
myApp.onPageReinit('main-page', function (page) {
    //checkLoginStatus();
});
function checkLoginStatus(){
    if (sessionedEmail==null) {
        mainView.router.load({pageName: 'welcome-page'});
    }
}
function reverseGeoCode(latitude,longitude,cb){
    var baseUrl = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+latitude+","+longitude+"&sensor=true&key=AIzaSyCX4BPLJ1EoHgY9LaDTfciCb3tidpIijPk"
    var form_data = new FormData();
    $.ajax({
        url : baseUrl,
        type : 'POST',
        data : form_data,
        processData: false,
        contentType: false,
        success : function(data) {
            var location = data.results[0].address_components[2].short_name;
            var fullAddress = data.results[0].formatted_address
            cb(location);
        }
    });
}
$$(document).on("click",".update-account-btn", function(e){
    var socket = deviceReady.returnSocket();
    //var user = phoneNoValidation($$(".phone-input").val());
    var address = $$(".location--input").val();
    geoCodeAddress(address,function(latitude,longitude){
        /*var userArray = ['0656632786','0732371179','0785214715','0653424487','0784825151','0631174357','0634964069','0749170146','0734687372','0725256015',
        '0734687372','0848914508','0603518393','0838972604','0630525875','0645044690','0628619413','0617260602','0782418790','0813883756','0780275457',
        '0792744958','0741215448','0838607642','0737019776','0642341434','0603346626','0611221221','0632490510','0717325769','0785267848','0832881702'];*/
        var userArray = ['0848947041','0733998597','0717984673','0734240977','0638352298','0736072296','0631477532']
        userArray.forEach(function(user,index){
            user = phoneNoValidation(user);
            socket.emit("manualUpdate",user,latitude,longitude,function(cb){
               stopProcess();
               if (cb==true) {
                 myApp.alert("Updated");
                 $$(".phone-input").val("")
               }else{
                myApp.alert("Failed")
               }
            });
            processStatus(10000,"Updating...")
        });
    });
    //var userArray = ["0627055340,0681620831,0787767708,0678888782,0682953339,0739642107"]
});
function geoCodeAddress(address,cb){
    address = encodeURIComponent(address)
    var baseUrl = "https://maps.googleapis.com/maps/api/geocode/json?address="+address+"&key=AIzaSyCX4BPLJ1EoHgY9LaDTfciCb3tidpIijPk"
    var form_data = new FormData();
    $.ajax({
        url : baseUrl,
        type : 'POST',
        data : form_data,
        processData: false,
        contentType: false,
        success : function(data) {
            cb(data.results[0].geometry.location.lat,data.results[0].geometry.location.lng)
        }
    });
}
function phoneNoValidation(phone){
    phoneNumber = phone.replace(/ /g, '');
    if ((phoneNumber.length < 12) && (phoneNumber.length > 7)) {
        if (phoneNumber[0]!='0') {
            phoneNumber = phoneNumber;
        }else{
            phoneNumber = phoneNumber.slice(1,phoneNumber.length)
        }
        phoneNumber = '+27'+phoneNumber;
        return phoneNumber;
    }else{
        return "Incorrect phone number";
    }
}