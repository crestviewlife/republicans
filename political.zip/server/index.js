var app     =     require("express")();
var mysql   =     require("mysql");
var http    =     require('http').Server(app);
var io      =     require("socket.io")(http);
var nodemailer = require('nodemailer');
var Twocheckout = require('2checkout-node');
var mkdirp = require('mkdirp');
var upload = require("express-fileupload");
var request = require('request');
app.use(upload());
app.use('/files',require("express").static(__dirname + '/files'));
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods', 'DELETE, PUT, POST, GET');
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  if ('OPTIONS' == req.method) {
    res.sendStatus(200);
  }
  else {
    next();
  }
});
var connection    =    mysql.createPool({
  connectionLimit   :   150,
  host              :   'localhost',
  port              :   3306,
  user              :   'root',
  password          :   '',
  database          :   'republicans',
  debug             :   false,
  multipleStatements : true
});
app.use('/files',require("express").static(__dirname + '/freenetserver'));
http.listen(9500, function() {
  console.log("Listening on 9500");
  connection.getConnection(function(err,conn){  
    if (!!err) {
      console.log("database Access Denied "+err);
    }else{
      conn.release();
      console.log("database Access granted");
    }
  });
  /*mkdirp('./files/items', function (err) {
   if (err) console.error(err)
   else console.log('directory files was created');
  });*/
});
io.sockets.on('connection', function (socket) {
  console.log('a user has connected client '+socket.id);
  socket.on("create-account", function(province,gender,occupation,fname,nationalId,email,city,password,position,cb){
    connection.query('SELECT * FROM users WHERE email=?', [email],function(err,result){
      if (result.length==0) {
        connection.query('INSERT INTO users SET ?', {province:province,gender:gender,occupation:occupation,fname:fname,nationalId:nationalId,email:email,city:city,password:password,position:position}, function (err, results, fields) {
          if (!err) {
            cb(true);
          }else{
            cb("Our server is currently down!, Please try again later!");
            console.log(err);
          }
        });
      }else{
        cb("The provided email address is already in use!")
      }
    });
  });
  socket.on("login", function(email,password,cb){
    connection.query('SELECT * FROM users WHERE email=? AND password=?', [email,password],function(err,result){
      if (!err) {
        cb(result)
      }
    });
  });
});
