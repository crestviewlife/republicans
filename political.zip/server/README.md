# node-js-getting-started

A barebones Node.js app using [Express 4](http://expressjs.com/).

This application supports the [Getting Started with Node on Heroku](https://devcenter.heroku.com/articles/getting-started-with-nodejs) article - check it out.

## Running Locally

Make sure you have [Node.js](http://nodejs.org/) and the [Heroku CLI](https://cli.heroku.com/) installed.

```sh
$ git clone git@github.com:heroku/node-js-getting-started.git # or clone your own fork
$ cd node-js-getting-started
$ npm install
$ npm start
```

Your app should now be running on [localhost:5000](http://localhost:5000/).

## Deploying to Heroku

```
$ heroku create
$ git push heroku master
$ heroku open
```
or

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)

## Documentation

For more information about using Node.js on Heroku, see these Dev Center articles:

- [Getting Started with Node.js on Heroku](https://devcenter.heroku.com/articles/getting-started-with-nodejs)
- [Heroku Node.js Support](https://devcenter.heroku.com/articles/nodejs-support)
- [Node.js on Heroku](https://devcenter.heroku.com/categories/nodejs)
- [Best Practices for Node.js Development](https://devcenter.heroku.com/articles/node-best-practices)
- [Using WebSockets on Heroku with Node.js](https://devcenter.heroku.com/articles/node-websockets)
socket.on('getRequests', function(latitude,longitude,gender){
    var beforeSortArray=[];
    pool.getConnection(function(err,connection){  
      if (!err) {
        connection.query('SELECT * FROM requests WHERE status=?', ['ready'],function(error,result){
          if (result.length>0) {
            if (!err) {
              for (var i = 0; i < result.length; i++){
                var id=result[i].id;
                var user=result[i].user;
                var reward=result[i].reward;
                var requestType=result[i].requestType;
                var requestTime=result[i].requestTime;
                var location=result[i].location;
                var db_latitude=result[i].latitude;
                var db_longitude=result[i].longitude;
                var distance=calcCrow(db_latitude,db_longitude,latitude,longitude).toFixed(1);
                beforeSortArray.push({distance:distance, id:id, user:user, reward:reward, requestType:requestType, requestTime:requestTime, location:location,db_latitude,db_longitude});
              }
              connection.release();
            }
          }
        });
      }
    });
    setTimeout(function(){
      var afterSortArray = beforeSortArray.sort((a, b) => Number(a.distance) - Number(b.distance));
      if (afterSortArray.length > 0) {
        for (var i = 0; i < afterSortArray.length; i++){
          var distance=afterSortArray[i].distance;
          var id=afterSortArray[i].id;
          var reward=afterSortArray[i].reward;
          var requestType=afterSortArray[i].requestType;
          var requestTime=afterSortArray[i].requestTime;
          var location=afterSortArray[i].location;
          var latitude=afterSortArray[i].db_latitude;
          var longitude=afterSortArray[i].db_longitude;
          var user=afterSortArray[i].user;
          socket.emit('getRequests', distance,id,reward,user,requestType,requestTime,location,latitude,longitude);
          console.log('.......... '+distance+'---- '+user)
        }
      }else{
        socket.emit('noNearByAgencies','THE SYSTEM COULD NOT FIND ANY NEAR BY AGENCIES, YOU CAN MANUALLY SEARCH')
      }
    },1000);
  });
